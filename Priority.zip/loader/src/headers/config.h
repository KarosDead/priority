#pragma once

#define HTTP_SERVER "45.130.141.13"
#define HTTP_PORT 80

#define TFTP_SERVER "45.130.141.13"
